package com.hax.nonroot;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private EditText codeInput;
    private Button verifyButton;
    private TextView status;
    private final int red = Color.rgb(215,25,32), gold = Color.rgb(224,177,72), dark = Color.rgb(8,8,8);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(dark); getWindow().setNavigationBarColor(dark);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setPadding(dp(26), dp(30), dp(26), dp(30)); root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Color.rgb(22,7,8), dark, Color.rgb(18,12,5)}));
        scroll.addView(root); setContentView(scroll);

        TextView crown = text("♛", 54, gold, true); root.addView(crown, params(-1,-2,0,0,0,0));
        TextView title = text("HAX_NON_ROOT", 29, Color.WHITE, true); title.setLetterSpacing(.08f); root.addView(title, params(-1,-2,0,4,0,0));
        TextView sub = text("SECURE ACCESS • ACTIVATION", 11, gold, true); sub.setLetterSpacing(.15f); root.addView(sub, params(-1,-2,0,8,0,0));
        View line = new View(this); line.setBackgroundColor(red); root.addView(line, params(dp(92),dp(3),0,24,0,24));

        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(20),dp(22),dp(20),dp(22)); card.setBackground(round(Color.rgb(17,17,18), gold, 1, 18)); root.addView(card, params(-1,-2,0,0,0,0));
        TextView welcome = text("WELCOME, NACER__22", 18, gold, true); welcome.setGravity(Gravity.CENTER); card.addView(welcome, params(-1,-2,0,0,0,0));
        TextView hint = text("Enter your activation key to continue", 14, Color.LTGRAY, false); hint.setGravity(Gravity.CENTER); card.addView(hint, params(-1,-2,0,12,0,18));
        codeInput = new EditText(this); codeInput.setSingleLine(true); codeInput.setTextColor(Color.WHITE); codeInput.setHintTextColor(Color.GRAY); codeInput.setHint("ACTIVATION CODE"); codeInput.setPadding(dp(14),0,dp(14),0); codeInput.setTextSize(15); codeInput.setInputType(0x00000001);
        codeInput.setBackground(round(Color.rgb(29,29,30), red, 1, 10)); card.addView(codeInput, params(-1,dp(54),0,0,0,16));
        verifyButton = new Button(this); verifyButton.setText("VERIFY KEY"); verifyButton.setTextColor(Color.WHITE); verifyButton.setTextSize(14); verifyButton.setTypeface(null,Typeface.BOLD); verifyButton.setAllCaps(false); verifyButton.setBackground(round(red, gold, 1, 10)); card.addView(verifyButton, params(-1,dp(52),0,0,0,0));
        status = text("Demo build • server verification enabled", 12, Color.LTGRAY, false); status.setGravity(Gravity.CENTER); root.addView(status, params(-1,-2,0,18,0,0));
        TextView footer = text("TEST BUILD  •  v1.0", 10, Color.GRAY, true); footer.setLetterSpacing(.12f); footer.setGravity(Gravity.CENTER); root.addView(footer, params(-1,-2,0,30,0,0));

        verifyButton.setOnClickListener(v -> verify());
    }
    private void verify() {
        String code = codeInput.getText().toString().trim();
        if (code.isEmpty()) { status.setTextColor(red); status.setText("Please enter your activation code."); return; }
        verifyButton.setEnabled(false); verifyButton.setText("CHECKING..."); status.setTextColor(gold); status.setText("Connecting to activation server...");
        new Thread(() -> {
            HttpURLConnection c = null; String message;
            try {
                URL url = new URL("https://key-system-yn0o.onrender.com/api/verify");
                c = (HttpURLConnection) url.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(15000); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID); if (device == null) device = "unknown-device";
                JSONObject body = new JSONObject(); body.put("code", code); body.put("device_id", device);
                try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes("UTF-8")); }
                java.io.InputStream is = (c.getResponseCode() >= 200 && c.getResponseCode() < 400) ? c.getInputStream() : c.getErrorStream();
                java.util.Scanner sc = new java.util.Scanner(is).useDelimiter("\\A"); String response = sc.hasNext()?sc.next():"{}";
                JSONObject json = new JSONObject(response);
                if (json.optBoolean("valid", false)) message = "ACTIVATION SUCCESSFUL ✓\nExpires: " + json.optString("expires_at", "unknown") + "\nDemo gate passed.";
                else message = "INVALID KEY: " + json.optString("reason", "Verification failed");
            } catch (Exception e) { message = "SERVER ERROR\n" + e.getClass().getSimpleName() + ": check connection and try again."; }
            finally { if (c != null) c.disconnect(); }
            final String result = message; runOnUiThread(() -> { verifyButton.setEnabled(true); verifyButton.setText("VERIFY KEY"); status.setText(result); status.setTextColor(result.startsWith("ACTIVATION SUCCESSFUL") ? gold : red); });
        }).start();
    }
    private TextView text(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); return t; }
    private GradientDrawable round(int color,int stroke,int width,int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(width),stroke); return d; }
    private LinearLayout.LayoutParams params(int w,int h,int l,int t,int r,int b) { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h); p.setMargins(l,t,r,b); return p; }
    private int dp(int x) { return (int)(x*getResources().getDisplayMetrics().density+.5f); }
}
