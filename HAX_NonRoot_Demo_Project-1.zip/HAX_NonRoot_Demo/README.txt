HAX NON ROOT DEMO

This is a standalone Android demo project. It does NOT modify or include the original app.
It creates a separate APK signed with Android's debug key when built by Gradle.

Build on GitHub using an Android phone:
1. Create a new GitHub repository.
2. Upload the CONTENTS of this folder (not the outer folder as a ZIP-only file) to the repository root.
3. Open Actions > Build demo APK > Run workflow (or push to main).
4. Open the completed run, scroll to Artifacts, and download HAX-NON-ROOT-Demo-APK.
5. Extract the artifact ZIP and install app-debug.apk.

The activation screen sends POST https://key-system-yn0o.onrender.com/api/verify
with code and Android ID. Successful verification only passes the demo gate; this demo does not launch or contain the original app.
