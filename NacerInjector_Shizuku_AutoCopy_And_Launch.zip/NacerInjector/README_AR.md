# Nacer Injector

مشروع Android Java يستخدم شاشة تفعيل المفتاح عبر السيرفر المحدد، ثم يعرض لوحة التحكم.

## تسلسل زر «اضغط هنا للبدء»
1. يتحقق من تشغيل Shizuku ومنح الصلاحية.
2. ينسخ الملفين المضمّنين في `app/src/main/assets/` إلى مساحة وسيطة خارجية خاصة بالتطبيق.
3. يستخدم Shizuku shell لإنشاء مجلد الوجهة ونسخ الملفين إلى:
   `/storage/emulated/0/Android/data/com.dts.freefireth/files/`
4. إذا وُجدت نسخ سابقة من الملفين، يحفظ نسخة احتياطية بامتداد `.bak` قبل تحديثها.
5. يتحقق من وجود الملفين ثم يفتح التطبيق ذي الحزمة `com.dts.freefireth`.

## الملفات المضمّنة
- `Assembly-CSharp-patch.bytes`
- `localConfig.json`

## البناء
افتح المجلد في Android Studio، ثم نفّذ Gradle task: `:app:assembleDebug`.

ملاحظة: المشروع مصدر Android وليس APK مبنيًا. نجاح النسخ يعتمد على إصدار Android وتشغيل Shizuku ومنح الصلاحية، كما يجب أن يكون التطبيق الهدف مثبتًا ويملك شاشة تشغيل.
