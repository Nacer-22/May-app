package com.nacer.injector;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_SHIZUKU = 4101;
    private static final String VERIFY_URL = "https://key-system-yn0o.onrender.com/api/verify";
    private static final int RED = Color.rgb(235, 35, 55);
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private EditText keyField;
    private TextView status, shizukuStatus;

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> runOnUiThread(() -> {
        refreshShizukuStatus();
        Toast.makeText(this, grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED ? "Shizuku permission granted" : "Shizuku permission denied", Toast.LENGTH_LONG).show();
    });

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(12,12,15));
        getWindow().setNavigationBarColor(Color.rgb(12,12,15));
        try { Shizuku.addRequestPermissionResultListener(permissionListener); } catch (Throwable ignored) {}
        buildLogin();
    }

    private LinearLayout page() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(12,12,15));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(root);
        setContentView(scroll);
        return root;
    }

    private void addSkull(LinearLayout root, int heightDp) {
        ImageView logo = new ImageView(this);
        logo.setImageResource(com.nacer.injector.R.drawable.nacer_skull);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(heightDp));
        lp.bottomMargin = dp(16);
        root.addView(logo, lp);
    }

    private void buildLogin() {
        LinearLayout root = page();
        addSkull(root, 250);
        TextView title = new TextView(this);
        title.setText("NACER INJECTOR");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView section = label("تفعيل المفتاح");
        section.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sectionLp = new LinearLayout.LayoutParams(-1, -2);
        sectionLp.topMargin = dp(28);
        root.addView(section, sectionLp);
        keyField = new EditText(this);
        keyField.setSingleLine(true);
        keyField.setHint("أدخل مفتاح التفعيل");
        keyField.setHintTextColor(Color.GRAY);
        keyField.setTextColor(Color.WHITE);
        keyField.setTextSize(15);
        keyField.setGravity(Gravity.CENTER_VERTICAL);
        keyField.setPadding(dp(14), 0, dp(14), 0);
        keyField.setBackground(roundRect(Color.rgb(24,24,29), dp(12), RED));
        LinearLayout.LayoutParams kl = new LinearLayout.LayoutParams(-1, dp(54));
        kl.topMargin = dp(14);
        root.addView(keyField, kl);
        Button activate = button("تفعيل");
        LinearLayout.LayoutParams ap = fullButton();
        ap.topMargin = dp(14);
        root.addView(activate, ap);
        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams st = new LinearLayout.LayoutParams(-1, -2);
        st.topMargin = dp(18);
        root.addView(status, st);
        activate.setOnClickListener(v -> verifyKey(activate));
    }

    private void buildDashboard(String expiresAt) {
        LinearLayout root = page();

        // Keep the original skull artwork, with a compact dashboard header.
        addSkull(root, 205);
        TextView title = new TextView(this);
        title.setText("NACER INJECTOR");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("لوحة التحكم");
        subtitle.setTextColor(RED);
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(6);
        subLp.bottomMargin = dp(28);
        root.addView(subtitle, subLp);

        shizukuStatus = new TextView(this);
        shizukuStatus.setTextColor(Color.LTGRAY);
        shizukuStatus.setTextSize(14);
        shizukuStatus.setGravity(Gravity.CENTER);
        shizukuStatus.setPadding(dp(12), dp(14), dp(12), dp(14));
        shizukuStatus.setBackground(roundRect(Color.rgb(22,22,27), dp(12), Color.rgb(65,35,40)));
        root.addView(shizukuStatus, new LinearLayout.LayoutParams(-1, -2));

        Button connect = button("اضغط للاتصال");
        LinearLayout.LayoutParams connectLp = fullButton();
        connectLp.topMargin = dp(14);
        root.addView(connect, connectLp);
        connect.setOnClickListener(v -> requestShizuku());

        Button start = button("اضغط هنا للبدء");
        LinearLayout.LayoutParams startLp = fullButton();
        startLp.topMargin = dp(18);
        root.addView(start, startLp);
        start.setOnClickListener(v -> {
            try {
                if (!Shizuku.pingBinder()) {
                    Toast.makeText(this, "افتح Shizuku ثم اضغط زر الاتصال أولاً", Toast.LENGTH_LONG).show();
                    return;
                }
                if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "امنح التطبيق صلاحية Shizuku أولاً", Toast.LENGTH_LONG).show();
                    requestShizuku();
                    return;
                }
                start.setEnabled(false);
                start.setText("جارٍ نسخ الملفين...");
                worker.execute(() -> {
                    String result = copyTestFilesWithShizuku();
                    runOnUiThread(() -> {
                        start.setEnabled(true);
                        start.setText("اضغط هنا للبدء");
                        if (result == null) {
                            Toast.makeText(this, "تم نسخ الملفين بنجاح", Toast.LENGTH_LONG).show();
                            openTargetApp();
                        } else {
                            Toast.makeText(this, "فشل النسخ: " + result, Toast.LENGTH_LONG).show();
                        }
                    });
                });
            } catch (Throwable t) {
                Toast.makeText(this, "تعذر التحقق من اتصال Shizuku", Toast.LENGTH_LONG).show();
            }
        });

        TextView footer = new TextView(this);
        footer.setText("Nacer_22");
        footer.setTextColor(Color.GRAY);
        footer.setTextSize(12);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, -2);
        footerLp.topMargin = dp(26);
        root.addView(footer, footerLp);
        refreshShizukuStatus();
    }

    private void verifyKey(Button button) {
        String code = keyField.getText().toString().trim();
        if (code.isEmpty()) { keyField.setError("Enter an activation key"); return; }
        button.setEnabled(false);
        button.setText("جارٍ التحقق...");
        status.setText("جارٍ التحقق من المفتاح...");
        status.setTextColor(Color.YELLOW);
        String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        final String deviceId = (id == null || id.isEmpty()) ? "android-device" : id;
        worker.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(VERIFY_URL).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                JSONObject payload = new JSONObject();
                payload.put("code", code);
                payload.put("device_id", deviceId);
                try (OutputStream out = connection.getOutputStream()) { out.write(payload.toString().getBytes(StandardCharsets.UTF_8)); }
                InputStream in = connection.getResponseCode() < 400 ? connection.getInputStream() : connection.getErrorStream();
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String line; while ((line = reader.readLine()) != null) body.append(line);
                }
                JSONObject result = new JSONObject(body.toString());
                boolean valid = result.optBoolean("valid", false);
                String expiry = result.optString("expires_at", "");
                String reason = result.optString("reason", "verification_failed");
                runOnUiThread(() -> {
                    if (valid) {
                        Toast.makeText(this, "Activation successful", Toast.LENGTH_SHORT).show();
                        buildDashboard(expiry);
                    } else {
                        button.setEnabled(true);
                        button.setText("تفعيل");
                        status.setText("تعذر تفعيل المفتاح: " + reason);
                        status.setTextColor(RED);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    button.setEnabled(true);
                    button.setText("تفعيل");
                    status.setText("تعذر الاتصال بالسيرفر. تحقق من الإنترنت.");
                    status.setTextColor(RED);
                });
            } finally { if (connection != null) connection.disconnect(); }
        });
    }


    // Copy the two bundled test files through Shizuku's shell identity.
    // Existing destination files are backed up before they are updated.
    private String copyTestFilesWithShizuku() {
        File staging = getExternalFilesDir("transfer");
        if (staging == null) return "تعذر الوصول إلى مساحة التخزين الخارجية";
        File patch = new File(staging, "Assembly-CSharp-patch.bytes");
        File config = new File(staging, "localConfig.json");
        try {
            copyAsset("Assembly-CSharp-patch.bytes", patch);
            copyAsset("localConfig.json", config);
            String dir = "/storage/emulated/0/Android/data/com.dts.freefireth/files";
            String p = shellQuote(patch.getAbsolutePath());
            String c = shellQuote(config.getAbsolutePath());
            String d = shellQuote(dir);
            String script = "set -e; mkdir -p " + d + "; " +
                "[ ! -f " + d + "/Assembly-CSharp-patch.bytes ] || cp -f " + d + "/Assembly-CSharp-patch.bytes " + d + "/Assembly-CSharp-patch.bytes.bak; " +
                "[ ! -f " + d + "/localConfig.json ] || cp -f " + d + "/localConfig.json " + d + "/localConfig.json.bak; " +
                "cp -f " + p + " " + d + "/Assembly-CSharp-patch.bytes; " +
                "cp -f " + c + " " + d + "/localConfig.json; " +
                "test -s " + d + "/Assembly-CSharp-patch.bytes; test -s " + d + "/localConfig.json; " +
                "echo COPY_OK";
            Process process = Shizuku.newProcess(new String[]{"sh", "-c", script}, null, null);
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line; while ((line = reader.readLine()) != null) output.append(line).append('\n');
            }
            StringBuilder errors = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream(), StandardCharsets.UTF_8))) {
                String line; while ((line = reader.readLine()) != null) errors.append(line).append('\n');
            }
            int exit = process.waitFor();
            if (exit == 0 && output.toString().contains("COPY_OK")) return null;
            return errors.length() > 0 ? errors.toString().trim() : "رمز الخروج " + exit;
        } catch (Exception e) {
            return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        }
    }

    private void copyAsset(String name, File destination) throws Exception {
        try (InputStream in = getAssets().open(name); FileOutputStream out = new FileOutputStream(destination)) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            out.flush();
        }
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private void openTargetApp() {
        final String targetPackage = "com.dts.freefireth";
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(targetPackage);
            if (launch == null) {
                Toast.makeText(this, "التطبيق nacer.apk غير مثبت أو لا يملك شاشة تشغيل", Toast.LENGTH_LONG).show();
                return;
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح التطبيق المستهدف", Toast.LENGTH_LONG).show();
        }
    }

    private void requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                new android.app.AlertDialog.Builder(this).setTitle("Shizuku is not running")
                    .setMessage("Start the Shizuku service, then return here.")
                    .setPositiveButton("Open Shizuku", (d, w) -> {
                        Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                        if (launch != null) startActivity(launch);
                        else Toast.makeText(this, "Shizuku is not installed.", Toast.LENGTH_LONG).show();
                    }).setNegativeButton("Cancel", null).show();
                return;
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                refreshShizukuStatus();
                Toast.makeText(this, "Shizuku permission already granted", Toast.LENGTH_SHORT).show();
            } else Shizuku.requestPermission(REQUEST_SHIZUKU);
        } catch (Throwable t) { Toast.makeText(this, "Could not connect to Shizuku", Toast.LENGTH_LONG).show(); }
    }

    private void refreshShizukuStatus() {
        if (shizukuStatus == null) return;
        try {
            boolean running = Shizuku.pingBinder();
            boolean granted = running && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
            shizukuStatus.setText(running ? (granted ? "Connected • Permission granted" : "Running • Permission required") : "Shizuku is not running");
            shizukuStatus.setTextColor(granted ? Color.rgb(100,220,140) : RED);
        } catch (Throwable t) { shizukuStatus.setText("Install and start Shizuku"); shizukuStatus.setTextColor(RED); }
    }

    @Override protected void onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permissionListener); } catch (Throwable ignored) {}
        worker.shutdownNow();
        super.onDestroy();
    }

    private TextView label(String text) {
        TextView v = new TextView(this); v.setText(text); v.setTextColor(RED); v.setTextSize(12);
        v.setLetterSpacing(0.1f); v.setTypeface(Typeface.DEFAULT_BOLD); return v;
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(13);
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT_BOLD); b.setBackground(roundRect(RED, dp(12), RED)); return b;
    }
    private LinearLayout.LayoutParams fullButton() { return new LinearLayout.LayoutParams(-1, dp(50)); }
    private android.graphics.drawable.GradientDrawable roundRect(int color, int radius, int stroke) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); d.setStroke(dp(1), stroke); return d;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
